# Get Papers

This is a Python tool to fetch research papers from PubMed with at least one author from a biotech/pharma company.

## 📦 Features
- Command-line interface
- Filters out academic authors
- Saves output to CSV
- Debug mode available

## 🧪 Tech Used
- Python 3.10+
- Poetry (for packaging)
- PubMed Entrez API
- Requests Library

## 🔧 Setup

```bash
pip install poetry
poetry install
```

## 🚀 Usage

```bash
poetry run get-papers-list "covid vaccine" -f results.csv
```

### Optional Flags
- `-d` or `--debug`: Print debug logs
- `-f filename.csv`: Save to CSV instead of printing

## 🧠 How It Works

- Uses PubMed search + fetch APIs.
- Identifies company authors by checking absence of words like `university`, `institute`, etc. in affiliations.

## 👩‍💻 Built By
Sakshi Sankpal – For internship purpose  
