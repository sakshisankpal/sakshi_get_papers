import argparse
import csv
from get_papers.fetch import fetch_papers

def write_csv(data, filename):
    if not data:
        print("No non-academic papers found.")
        return
    with open(filename, "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)
    print(f"Results saved to {filename}")

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with biotech/pharma company authors.")
    parser.add_argument("query", help="PubMed query string")
    parser.add_argument("-d", "--debug", action="store_true", help="Print debug info")
    parser.add_argument("-f", "--file", help="Save results to CSV file")

    args = parser.parse_args()
    papers = fetch_papers(args.query, debug=args.debug)

    if args.file:
        write_csv(papers, args.file)
    else:
        for p in papers:
            print(p)

if __name__ == "__main__":
    main()
