from typing import List, Dict
import requests
from get_papers.utils import is_non_academic

def fetch_papers(query: str, debug: bool = False) -> List[Dict]:
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": 10,
        "retmode": "json"
    }

    res = requests.get(base_url, params=params)
    ids = res.json()["esearchresult"]["idlist"]
    if debug:
        print(f"Found PubMed IDs: {ids}")

    details_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
    details = requests.post(details_url, params={
        "db": "pubmed",
        "retmode": "xml",
        "id": ",".join(ids)
    })

    from xml.etree import ElementTree as ET
    root = ET.fromstring(details.text)

    results = []
    for article in root.findall(".//PubmedArticle"):
        pmid = article.findtext(".//PMID")
        title = article.findtext(".//ArticleTitle")
        pub_date = article.findtext(".//PubDate/Year") or "Unknown"
        authors = article.findall(".//Author")
        non_academic_authors = []
        company_affiliations = []
        email = None

        for author in authors:
            aff = author.findtext("AffiliationInfo/Affiliation") or ""
            name = (author.findtext("ForeName") or "") + " " + (author.findtext("LastName") or "")
            if "@" in aff:
                email = aff.split()[-1]
            if is_non_academic(aff):
                non_academic_authors.append(name)
                company_affiliations.append(aff)

        if non_academic_authors:
            results.append({
                "PubmedID": pmid,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": "; ".join(non_academic_authors),
                "Company Affiliation(s)": "; ".join(company_affiliations),
                "Corresponding Author Email": email or "N/A"
            })

    return results
