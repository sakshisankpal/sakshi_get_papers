def is_non_academic(affiliation: str) -> bool:
    academic_keywords = ["university", "college", "institute", "school", "dept", "department"]
    affiliation = affiliation.lower()
    return not any(word in affiliation for word in academic_keywords)
